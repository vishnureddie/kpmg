$(document).ready(function(){
    $('.carousel').carousel({
        interval: 2000
    });
    animateSlider();
	if($('.carousel').attr('data-slider') == 'HOME')
    setInterval(moveSlider, 5000);
});

function moveSlider(){
    $('.carousel-control-next').trigger('click');
    animateSlider();
}

function animateSlider(){
    $('.trans-overlay').css({"left":"2000px"}).animate({"left":"0px"}, 1000);
    $('.left-overlay').css({"left":"200px"}).animate({"left":"0px"}, 2000);
    $('.carousel-caption').css({"margin-left":"-300px"}).animate({"margin-left":"0px"}, 2200);
}

// News & Events
 $('.scroller').owlCarousel({
    loop:true,
    dots:false,
	nav:true,
	responsiveClass:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
});


$('.quicklink_scroller').owlCarousel({
    loop:true,
	responsiveClass:true,
	autoplay:true,  
	dots:false,  
	nav:false,
    responsive:{
        0:{
            items:2
        },
        600:{
            items:2
        },
        1000:{
            items:5
        }
    }
});

$('.grid_carousel').owlCarousel({
	responsiveClass:true,
    margin:10,
    autoplay:true,
	dots:true,  
    nav:false,
    responsive:{
        0:{
            items:3
        },
        600:{
            items:4
        },
        1000:{
           items: 6,
        }
    }
})

$('.mediagallery_scroller').owlCarousel({
    loop:true,
	responsiveClass:true,
	autoplay:false,  
	dots:false,  
	nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});


//Search Icon

$(function () {
    //$("#search-menu").removeClass("toggled");



    $("#search-icon").click(function (e) {
        //e.stopPropagation();
        $("#search-menu").addClass("toggled");
        $("#popup-search").focus();
    });

    $("#search-menu input").click(function (e) {
        //e.stopPropagation();
    	
    });



    $("#close-button").click(function () {
        console.log("close-button");

         $("#search-menu").removeClass("toggled");
    });
});

//Feedback Form
$(document).ready(function() {
    $('.comment').hide();
    $('.otp').hide();
});

$('#sendotp').click(function(){
    $('.otpmessage').show();
    $('.otp').show();
    $('#sendotp').addClass('d-none');
    $('#submitotp').removeClass('d-none');
});

$('#submitotp').click(function(){
    $('.otp').hide();
    $('.comment').show();
    $('.otpmessage').hide();
    $('#submitotp').addClass('d-none');
    $('#submitform').removeClass('d-none');
});


//TAB TO  ACCORDION
$(document).ready(function(){
    // Add minus icon for collapse element which is open by default
    $(".collapse.show").each(function(){
        $(this).prev(".card-header").find(".fa").addClass("fa-minus").removeClass("fa-plus");
    });

    // Toggle plus minus icon on show hide of collapse element
    $(".collapse").on('show.bs.collapse', function(){
        $(this).prev(".card-header").find(".fa").removeClass("fa-plus").addClass("fa-minus");
    }).on('hide.bs.collapse', function(){
        $(this).prev(".card-header").find(".fa").removeClass("fa-minus").addClass("fa-plus");
    });
});


//Font Increase Decrease
   var $affectedElements = $("main p, main a, main li, main h1, main h2, main h3, main h4, main h5, main h6, .header_bottom a"); // Can be extended, ex. $("div, p, span.someClass")
var clickcount=0;	
// Storing the original size in a data attribute so size can be reset
$affectedElements.each( function(){
  
  var $this = $(this);
  $this.data("orig-size", $this.css("font-size") );
});

$("#btn-increase").click(function(){
	
	if(clickcount<=1){
		clickcount=clickcount+1;
         changeFontSize(1);
	}
	//alert("clickCounts"+clickcount);
})

$("#btn-decrease").click(function(){
	
	if(clickcount>=-1){
		
		clickcount=clickcount-1;
             changeFontSize(-1);
	}
	
	//alert("clickCounts"+clickcount);
})

$("#btn-orig").click(function(){
	clickcount=0;
  $affectedElements.each( function(){
        var $this = $(this);
        $this.css( "font-size" , $this.data("orig-size") );
   });
})

var defaultFontSize = $('main p, main a, main li, main h1, main h2, main h3, main h4, main h5, main h6, .header_bottom a').css('font-size');
 $affectedElements.each( function(){
  var $this = $(this);
  $this.data("orig-size", $this.css("font-size") );
});

$(".resetFont").click(function () {
    $('main p, main a, main li, main h1, main h2, main h3, main h4, main h5, main h6, .header_bottom a').css('font-size', '16px');
});
$(".increaseFont").click(function () {
    var fontSize = getFontSize();
    var newFontSize = fontSize + 1;
    setFontSize(newFontSize);
    return false;
});
$(".decreaseFont").click(function () {
    var fontSize = getFontSize();
    var newFontSize = fontSize - 1;
    setFontSize(newFontSize);
    return false;
});
function changeFontSize(direction){
    $affectedElements.each( function(){
        var $this = $(this);
		console.log($this.css("font-size"));
        $this.css( "font-size" , parseInt($this.css("font-size"))+direction );
    });
}


//Dark Mode
function myFunction() {
   var element = document.body;
   element.classList.toggle("dark-mode");
}


//News List on homepage

	jQuery.fn.liScroll = function(settings) {
		settings = jQuery.extend({
			travelocity: 0.02 
		}, settings);		
			return this.each(function(){
					var $strip = jQuery(this);
					$strip.addClass("newsticker")
					var stripHeight = 1;
					$strip.find("li").each(function(i){
						stripHeight += jQuery(this, i).outerHeight(true); 
					});
					var $mask = $strip.wrap("<div class='mask'></div>");
					var $tickercontainer = $strip.parent().wrap("<div class='tickercontainer'></div>");								
					var containerHeight = $strip.parent().parent().height();	 	
					$strip.height(stripHeight);			
					var totalTravel = stripHeight;
					var defTiming = totalTravel/settings.travelocity;			
					function scrollnews(spazio, tempo){
					$strip.animate({top: '-='+ spazio}, tempo, "linear", function(){$strip.css("top", containerHeight); scrollnews(totalTravel, defTiming);});
					}
					scrollnews(totalTravel, defTiming);				
					$strip.hover(function(){
					  jQuery(this).stop();
					},
					function(){
					  var offset = jQuery(this).offset();
					  var residualSpace = offset.top + stripHeight;
					  var residualTime = residualSpace/settings.travelocity;
					  scrollnews(residualSpace, residualTime);
					});			
			});	
	};


var section = document.querySelector('.numbers');
var hasEntered = false;

window.addEventListener('scroll', (e) => {
	var shouldAnimate = (window.scrollY + window.innerHeight) >= section.offsetTop;

	if (shouldAnimate && !hasEntered) {
  	hasEntered = true;
    
    $('.value').each(function () {
    	$(this).prop('Counter',0).animate({
        Counter: $(this).text()
    	}, {
        duration: 3000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
   		});
    });

  }
});




$(function(){
    $("ul#ticker01").liScroll();
});



//Value Counters

const counters = document.querySelectorAll('.counter_number');
const speed = 1000;
counters.forEach( counter => {
   const animate = () => {
      const value = +counter.getAttribute('value');
      const data = +counter.innerText;
     
      const time = value / speed;
     if(data < value) {
          counter.innerText = Math.ceil(data + time);
          setTimeout(animate, 1);
        }else{
          counter.innerText = value;
        }
   }
   
   animate();
});


