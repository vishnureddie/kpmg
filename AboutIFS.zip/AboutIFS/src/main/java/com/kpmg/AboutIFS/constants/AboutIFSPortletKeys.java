package com.kpmg.AboutIFS.constants;

/**
 * @author VISHNU
 */
public class AboutIFSPortletKeys {

	public static final String ABOUTIFS =
		"com_kpmg_AboutIFS_AboutIFSPortlet";
	public static final String ABOUTIFS_FILE_CHOOSE_TYPE=".jpg,.png,.gif,.webp";
	public static final String ABOUTIFS_FILE_UPLOAD_TYPES = "jpg,png,gif,webp";

}